export default defineNuxtRouteMiddleware((to, from) => {
  
})
