<template>
    <h1>Default layout</h1>
    <slot/>
</template>