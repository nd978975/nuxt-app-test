<template>
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1>Page Heading</h1>
  </div>
</template>
