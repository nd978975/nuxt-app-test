
import { defuFn } from 'C:/Users/MEOMUN/Downloads/Source code/blog-nuxt/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
