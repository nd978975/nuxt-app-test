<template>
  <div class="container">
    <form action="">
      <div class="form-group">
        <label for="">Image upload</label>
        <input type="file" class="form-control">
      </div>
    </form>
  </div>
</template>