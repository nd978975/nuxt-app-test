<template>
  <h1>Trang admin</h1>
</template>

<script setup >
definePageMeta({
    layout: 'backend',
    middleware: ['auth']
})
</script>