<template>
  <h1>User trash</h1>
</template>