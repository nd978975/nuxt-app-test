<template>
  <h1>User public</h1>
</template>