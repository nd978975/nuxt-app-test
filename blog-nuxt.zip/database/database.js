export default category = {
  name: "Chuyên khoa đào tạo",
  slug: "chuyen-khoa-dao-tao"
}